package com.wannik.jsp.model;

public class DatabaseInfo {
    public static final String URL = "jdbc:mysql://localhost/bookshop";
    public static final String USER = "root";
    public static final String PASSWORD = "123";
    public static final String DRIVER = "com.mysql.jdbc.Driver";
    
    private DatabaseInfo() {
    }
}