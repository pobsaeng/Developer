package com.wannik.jsp.model;

import java.util.*;

public class OrderTable {
    private Database db;
    
    public OrderTable(Database db) {
        this.db = db;
    }
    
    public void add(Order order) {
        String sql = "INSERT INTO `order`"
                     + " (member_id, date, shipping_address)"
                     + " VALUES(?, ?, ?)";
        int    id  = db.add(sql, 
                            order.getMember().getId(), 
                            order.getDate(), 
                            order.getShippingAddress());
        
        order.setId(id);
    }

    public List<Order> findAll() {
        List<Order> list = new ArrayList<Order>();
        String      sql  = "SELECT *,`order`.id as order_id FROM `order`"
                           + " INNER JOIN member"
                             + " ON `order`.member_id = member.id"
                           + " ORDER BY date DESC";
        
        List<Map<String, Object>> result = db.queryList(sql);

        for (Map<String, Object> row : result) {
            Member c;
            c = new Member((Integer) row.get("member_id"), 
                           (String) row.get("username"), 
                           (String) row.get("password"), 
                           (String) row.get("name"), 
                           (String) row.get("address"), 
                           (String) row.get("email"),
                           (Boolean) row.get("activated"),
                           (String) row.get("activate_code"),
                           (Date) row.get("register_date"));
            Order order;
            order = new Order((Integer) row.get("order_id"), 
                              c,
                              (Date) row.get("date"), 
                              (String) row.get("shipping_address"));

            list.add(order);
        }
 
        return list;
    }
}