package com.wannik.jsp.model;

import java.util.*;

public class OrderDetailTable {
    private Database db;
    
    public OrderDetailTable(Database db) {
        this.db = db;
    }
    
    public void add(OrderDetail orderDetail) {
        String sql = "INSERT INTO order_detail"
                     + " (order_id, book_id, amount)"
                     + " VALUES(?, ?, ?)";
        int    id  = db.add(sql, 
                            orderDetail.getOrder().getId(), 
                            orderDetail.getBook().getId(), 
                            orderDetail.getAmount());
        
        orderDetail.setId(id);
    }

    public List<OrderDetail> findByOrderId(int order_id) {
        List<OrderDetail> list = new ArrayList<OrderDetail>();
        String            sql  = "SELECT *,order_detail.id as order_detail_id" 
                                 + " FROM order_detail"
                                 + " INNER JOIN `order`"
                                   + " ON order_detail.order_id=`order`.id"
                                 + " INNER JOIN member"
                                   + " ON `order`.member_id=member.id"
                                 + " INNER JOIN book"
                                   + " ON order_detail.book_id=book.id"
                                 + " WHERE order_detail.order_id=?"
                                 + " ORDER BY `order`.id";
        
        List<Map<String, Object>> result = db.queryList(sql, order_id);

        for (Map<String, Object> row : result) {
            Book        book        = new Book((Integer) row.get("book_id"), 
                                               (String) row.get("title"), 
                                               (String) row.get("authors"), 
                                               (Integer) row.get("price"), 
                                               (Integer) row.get("stock"));
            Member      member      = new Member((Integer) row.get("member_id"), 
                                                 (String) row.get("username"), 
                                                 (String) row.get("password"), 
                                                 (String) row.get("name"), 
                                                 (String) row.get("address"), 
                                                 (String) row.get("email"),
                                                 (Boolean) row.get("activated"),
                                                 (String) row.get("activate_code"),
                                                 (Date) row.get("register_date"));
            Order       order       = new Order((Integer) row.get("order_id"), 
                                                member,
                                                (Date) row.get("date"), 
                                                (String) row.get("shipping_address"));
            OrderDetail orderDetail = new OrderDetail((Integer) row.get("order_detail_id"),
                                                      order,
                                                      book,
                                                      (Integer) row.get("amount"));

            list.add(orderDetail);
        }
 
        return list;
    }
}