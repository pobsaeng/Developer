package com.wannik.jsp.model;

import java.util.*;

public class MemberTable {
    private Database db;
    
    public MemberTable(Database db) {
        this.db = db;
    }
    
    public void deleteUnactivated() {
        String sql = "DELETE FROM member" 
                     + " WHERE activated=0" 
                       + " AND DATEDIFF(CURDATE(), register_date) > 7";
        
        db.update(sql);
    }
    
    public boolean add(Member member) {
        String sql = "INSERT INTO member"
                     + " (username, password, name, address, email, activated," 
                       + " activate_code, register_date)"
                     + " VALUES(?, ?, ?, ?, ?, ?, ?, ?)";
        
        try {
            int    id  = db.add(sql, 
                                member.getUsername(),
                                member.getPassword(),
                                member.getName(),
                                member.getAddress(),
                                member.getEmail(),
                                member.isActivated(),
                                member.getActivateCode(),
                                member.getRegisterDate());

            member.setId(id);
            
            return true;
        }
        catch (Exception e) {
            return false;
        }
    }
    
    public void update(Member member) {
        String sql = "UPDATE member"
                     + " SET username=?, password=?, name=?, address=?,"
                       + " email=?, activated=?, activate_code=?,"
                       + " register_date=?"
                     + " WHERE id=?";
        
        db.update(sql, 
                  member.getUsername(),
                  member.getPassword(),
                  member.getName(),
                  member.getAddress(),
                  member.getEmail(),
                  member.isActivated(),
                  member.getActivateCode(),
                  member.getRegisterDate(),
                  member.getId());
    }
    
    public Member findById(int id) {
        String              sql    = "SELECT * FROM member WHERE id=?";
        Map<String, Object> result = db.querySingle(sql, id);

        if (result != null) {
            return new Member(id, 
                              (String) result.get("username"), 
                              (String) result.get("password"), 
                              (String) result.get("name"), 
                              (String) result.get("address"), 
                              (String) result.get("email"),
                              (Boolean) result.get("activated"),
                              (String) result.get("activate_code"),
                              (Date) result.get("register_date"));
        }
        else {
            return null;
        }
    }
    
    public Member findByUsername(String username) {
        String              sql    = "SELECT * FROM member WHERE username=?";
        Map<String, Object> result = db.querySingle(sql, username);

        if (result != null) {
            return new Member((Integer) result.get("id"), 
                              username, 
                              (String) result.get("password"), 
                              (String) result.get("name"), 
                              (String) result.get("address"), 
                              (String) result.get("email"),
                              (Boolean) result.get("activated"),
                              (String) result.get("activate_code"),
                              (Date) result.get("register_date"));
        }
        else {
            return null;
        }
    }
    
    public Member findByUP(String username, String password) {
        String              sql    = "SELECT * FROM member"
                                     + " WHERE username=? AND password=?";
        Map<String, Object> result = db.querySingle(sql, username, password);

        if (result != null) {
            return new Member((Integer) result.get("id"), 
                              (String) result.get("username"), 
                              (String) result.get("password"), 
                              (String) result.get("name"), 
                              (String) result.get("address"), 
                              (String) result.get("email"),
                              (Boolean) result.get("activated"),
                              (String) result.get("activate_code"),
                              (Date) result.get("register_date"));
        }
        else {
            return null;
        }
    }
}