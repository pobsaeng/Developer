package com.wannik.jsp.model;

import java.util.*;
 
public class BookTable {
    private Database db;
    
    public BookTable(Database db) {
        this.db = db;
    }
    
    public void add(Book book) {
        String sql = "INSERT INTO book"
                     + " (title, authors, price, stock)"
                     + " VALUES(?, ?, ?, ?)";
        int    id  = db.add(sql, 
                            book.getTitle(), 
                            book.getAuthors(), 
                            book.getPrice(),
                            book.getStock());
        
        book.setId(id);
    }
    
    public void update(Book book) {
        String sql = "UPDATE book"
                     + " SET title=?, authors=?, price=?, stock=?"
                     + " WHERE id=?";
        
        db.update(sql, 
                  book.getTitle(), 
                  book.getAuthors(), 
                  book.getPrice(), 
                  book.getStock(),
                  book.getId());
    }
    
    public void remove(int id) {
        String sql = "DELETE FROM book"
                     + " WHERE id=?";
        
        db.remove(sql, id);
    }
    
    public Book findById(int id) {
        String              sql    = "SELECT * FROM book WHERE id=?";
        Map<String, Object> result = db.querySingle(sql, id);

        return new Book(id, 
                        (String) result.get("title"), 
                        (String) result.get("authors"), 
                        (Integer) result.get("price"), 
                        (Integer) result.get("stock"));
    }
    
    public List<Book> findAll() {
        return findByKeyword("", 0, getSize(""));
    }

    public List<Book> findByKeyword(String keyword, int start, int size) {
        List<Book> list = new ArrayList<Book>();
        String     sql  = "SELECT * FROM book"
                          + " WHERE title LIKE ? OR authors LIKE ?"
                          + " ORDER BY title"
                          + " LIMIT " + start + ", " + size;

        List<Map<String, Object>> result = db.queryList(sql, 
                                                        "%" + keyword + "%", 
                                                        "%" + keyword + "%");

        for (Map<String, Object> row : result) {
            Book book = new Book((Integer) row.get("id"), 
                                 (String) row.get("title"), 
                                 (String) row.get("authors"), 
                                 (Integer) row.get("price"), 
                                 (Integer) row.get("stock"));

            list.add(book);
        }
 
        return list;
    }
    
    public int getSize(String keyword) {
        String              sql    = "SELECT COUNT(*) FROM book"
                                     + " WHERE title LIKE ? OR authors LIKE ?";
        Map<String, Object> result = db.querySingle(sql, 
                                                    "%" + keyword + "%", 
                                                    "%" + keyword + "%");

        return ((Long) result.get("COUNT(*)")).intValue();
    }
}