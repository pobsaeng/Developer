package com.wannik.jsp.filter;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class ThaiRequest implements Filter {
    //  Init
    public void init(FilterConfig filterConfig) {
    }

    //  Do Filter
    public void doFilter(ServletRequest request, ServletResponse response,
                         FilterChain chain)
        throws IOException, ServletException {
        HttpServletRequest myRequest = (HttpServletRequest) request;
        
        myRequest.setCharacterEncoding("UTF-8");
        
        chain.doFilter(request, response);
    }
    
    //  Destroy
    public void destroy() {
    }
}