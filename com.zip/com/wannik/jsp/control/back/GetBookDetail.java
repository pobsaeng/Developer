package com.wannik.jsp.control.back;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

import com.wannik.jsp.model.*;

public class GetBookDetail extends HttpServlet {
    protected void processRequest(HttpServletRequest request, 
                                  HttpServletResponse response)
            throws ServletException, IOException {
        //  Prepare Input
        int id = Integer.parseInt(request.getParameter("id"));

        //  Call Model
        Database  db        = new Database();
        BookTable bookTable = new BookTable(db);
        Book      book      = bookTable.findById(id);
        
        db.close();

        //  Go to View
        request.setAttribute("book", book);

        RequestDispatcher rd = request.getRequestDispatcher("edit_book.jsp");
        
        rd.forward(request, response);
    } 

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
    * Handles the HTTP <code>GET</code> method.
    * @param request servlet request
    * @param response servlet response
    */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    } 

    /** 
    * Handles the HTTP <code>POST</code> method.
    * @param request servlet request
    * @param response servlet response
    */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
    * Returns a short description of the servlet.
    */
    public String getServletInfo() {
        return "Short description";
    }
    // </editor-fold>
}