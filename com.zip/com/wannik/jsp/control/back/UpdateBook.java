package com.wannik.jsp.control.back;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javazoom.upload.*;

import com.wannik.jsp.model.*;
import com.wannik.jsp.util.*;

public class UpdateBook extends HttpServlet {
    protected void processRequest(HttpServletRequest request, 
                                  HttpServletResponse response)
            throws ServletException, IOException {
      try {
        //  Prepare Input
        MultipartFormDataRequest mrequest 
                = new MultipartFormDataRequest(request);
        
        int        id      = Integer.parseInt(mrequest.getParameter("id"));
        String     title   = Utility.convertThai(mrequest.getParameter("title"));
        String     authors = Utility.convertThai(mrequest.getParameter("authors"));
        int        price   = Integer.parseInt(mrequest.getParameter("price"));
        int        stock   = Integer.parseInt(mrequest.getParameter("stock"));
        UploadFile pic     = (UploadFile) mrequest.getFiles().get("picture");
        
        //  Validate Input
        if (pic.getFileSize() != -1) {
            String error = "";
            
            if (pic.getFileSize() > 50*1024) {
                error = "ขนาดไฟล์รูปภาพต้องไม่เกิน 50 กิโลไบต์";
            }
            else if (!pic.getContentType().equals("image/gif")) {
                error = "ไฟล์รูปภาพต้องเป็น gif";
            }

            if (error.length() > 0) {
                Book book = new Book(id, title, authors, price, stock);

                request.setAttribute("invalidPicture", error);
                request.setAttribute("book", book);

                RequestDispatcher rd = request.getRequestDispatcher("edit_book.jsp");

                rd.forward(request, response);

                return;
            }
        }
        
        //  Call Model
            //  Data
        Database  db        = new Database();
        BookTable bookTable = new BookTable(db);
        Book      book      = new Book(id, title, authors, price, stock);
        
        bookTable.update(book);
        db.close();
        
            //  File
        if (pic.getFileSize() != -1) {        
            UploadBean upBean = new UploadBean();

            pic.setFileName(book.getId() + ".gif");
            upBean.setFolderstore(getServletContext().getRealPath("/images"));
            upBean.setOverwrite(true);
            upBean.store(mrequest);
        }

        //  Go to View
        response.sendRedirect("ShowAllBooks");
      }
      catch (UploadException ex) {
        throw new RuntimeException(ex.getMessage());
      }
    } 

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
    * Handles the HTTP <code>GET</code> method.
    * @param request servlet request
    * @param response servlet response
    */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    } 

    /** 
    * Handles the HTTP <code>POST</code> method.
    * @param request servlet request
    * @param response servlet response
    */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
    * Returns a short description of the servlet.
    */
    public String getServletInfo() {
        return "Short description";
    }
    // </editor-fold>
}