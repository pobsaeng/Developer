package com.wannik.jsp.control.shop;

import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;

import com.wannik.jsp.model.*;

public class SearchResult extends HttpServlet {
    public static final int ITEM_PER_PAGE = 4;

    protected void processRequest(HttpServletRequest request, 
                                  HttpServletResponse response)
            throws ServletException, IOException {
        //  Prepare Input
        String keyword = (request.getParameter("keyword") != null
                          ? request.getParameter("keyword")
                          : "");
        int    pageNo  = (request.getParameter("page_no") != null
                          && request.getParameter("page_no").length() > 0
                          ? Integer.parseInt(request.getParameter("page_no"))
                          : 0);
            
        //  Call Model
        Database   db        = new Database();
        BookTable  bookTable = new BookTable(db);
        int        numRecord = bookTable.getSize(keyword);
        Page       page      = new Page(numRecord, pageNo, ITEM_PER_PAGE);
        List<Book> result    = bookTable.findByKeyword(keyword, 
                                                       page.getFromIndex(), 
                                                       ITEM_PER_PAGE);
        int        pageCount = page.size();
        
        db.close();

        //  Go to View
        request.setAttribute("result", result);
        request.setAttribute("pageCount", pageCount);
        request.getSession().setAttribute("keyword", keyword);
        request.getSession().setAttribute("pageNo", pageNo);

        RequestDispatcher rd = request.getRequestDispatcher(
                                "search_result.jsp");
        
        rd.forward(request, response);
    } 

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
    * Handles the HTTP <code>GET</code> method.
    * @param request servlet request
    * @param response servlet response
    */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    } 

    /** 
    * Handles the HTTP <code>POST</code> method.
    * @param request servlet request
    * @param response servlet response
    */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
    * Returns a short description of the servlet.
    */
    public String getServletInfo() {
        return "Short description";
    }
    // </editor-fold>
}