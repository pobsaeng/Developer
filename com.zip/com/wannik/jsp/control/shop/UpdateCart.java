package com.wannik.jsp.control.shop;

import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;

import com.wannik.jsp.model.*;
import com.wannik.jsp.util.*;

public class UpdateCart extends HttpServlet {
    protected void processRequest(HttpServletRequest request, 
                                  HttpServletResponse response)
            throws ServletException, IOException {
        //  Prepare Input
        String[] removes = request.getParameterValues("remove");
        String[] amounts = request.getParameterValues("amount");
        String[] ids     = request.getParameterValues("id");
        
        if (removes == null) {
            removes = new String[0];
        }
        
        //  Validate Input
        Map<Integer, String> errors = new HashMap<Integer, String>();
        
        for (int i = 0; i < ids.length; i++) {
            if (!Utility.isNumber(amounts[i])) {
                errors.put(Integer.parseInt(ids[i]), "เลขจำนวนเต็ม");
            }
            else if (Integer.parseInt(amounts[i]) <= 0) {
                errors.put(Integer.parseInt(ids[i]), "เลขบวก");
            }
        }
        
        if (errors.size() > 0) {
            request.setAttribute("errors", errors);

            RequestDispatcher rd = request.getRequestDispatcher("shopping_cart.jsp");

            rd.forward(request, response);

            return;
        }
        
        //  Call Model
            //  Cart
        HttpSession  session = request.getSession();
        ShoppingCart cart    = (ShoppingCart) session.getAttribute("cart");
        
            //  Update
        for (int i = 0; i < ids.length; i++) {
            int id     = Integer.parseInt(ids[i]);
            int amount = Integer.parseInt(amounts[i]);
            
            cart.update(id, amount);
        }
        
            //  Remove
        for (int i = 0; i < removes.length; i++) {
            int id = Integer.parseInt(removes[i]);
            
            cart.remove(id);
        }
        
        //  Go to View
        response.sendRedirect("ShowCart");
    } 

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
    * Handles the HTTP <code>GET</code> method.
    * @param request servlet request
    * @param response servlet response
    */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    } 

    /** 
    * Handles the HTTP <code>POST</code> method.
    * @param request servlet request
    * @param response servlet response
    */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
    * Returns a short description of the servlet.
    */
    public String getServletInfo() {
        return "Short description";
    }
    // </editor-fold>
}