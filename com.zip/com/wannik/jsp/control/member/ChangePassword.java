package com.wannik.jsp.control.member;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

import com.wannik.jsp.model.*;

public class ChangePassword extends HttpServlet {
    protected void processRequest(HttpServletRequest request, 
                                  HttpServletResponse response)
            throws ServletException, IOException {
        //  Prepare Input
        String oldPass     = request.getParameter("old");
        String newPass     = request.getParameter("new");
        String confirmPass = request.getParameter("confirm");
        
        //  Validate Input
        if (!newPass.equals(confirmPass)) {
            request.setAttribute("confirmIncorrect", "รหัสผ่านไม่ตรงกัน");

            RequestDispatcher rd = request.getRequestDispatcher("change_password.jsp");
            
            rd.forward(request, response);
            
            return;
        }
        
        //  Call Model
            //  Member
        HttpSession session = request.getSession();
        Member      member  = (Member) session.getAttribute("member");
        
            //  Change to New Password
        boolean oldMatch = (member.getPassword().equals(oldPass));
        
        if (oldMatch) {
            Database    db          = new Database();
            MemberTable memberTable = new MemberTable(db);

            member.setPassword(newPass);
            memberTable.update(member);
            db.close();
        }
        
        //  Go to View
        if (oldMatch) {
            response.sendRedirect("change_password_completed.jsp");
        }
        else {
            request.setAttribute("oldIncorrect", "รหัสผ่านผิด");

            RequestDispatcher rd = request.getRequestDispatcher("change_password.jsp");
            
            rd.forward(request, response);
        }
    } 

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
    * Handles the HTTP <code>GET</code> method.
    * @param request servlet request
    * @param response servlet response
    */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    } 

    /** 
    * Handles the HTTP <code>POST</code> method.
    * @param request servlet request
    * @param response servlet response
    */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
    * Returns a short description of the servlet.
    */
    public String getServletInfo() {
        return "Short description";
    }
    // </editor-fold>
}