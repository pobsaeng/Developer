package com.wannik.jsp.control.member;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

import com.wannik.jsp.model.*;
import com.wannik.jsp.util.*;

public class ForgotPassword extends HttpServlet {
    protected void processRequest(HttpServletRequest request, 
                                  HttpServletResponse response)
            throws ServletException, IOException {
        //  Prepare Input
        String username = request.getParameter("username");

        //  Call Model
            //  Get Data
        Database    db          = new Database();
        MemberTable memberTable = new MemberTable(db);
        Member      member      = memberTable.findByUsername(username);
        
        db.close();
        
            //  Send E-mail
        if (member != null) {
            String from    = "no-reply@wannik.com";
            String to      = member.getEmail();
            String subject = "ลืมรหัสผ่าน";
            String body    = "คุณได้แจ้งว่าลืมรหัสผ่านกับเรา<br />"
                             + "โปรดยืนยันการเปลี่ยนรหัสผ่านใหม่โดยคลิก"
                             + "<b><a href='http://localhost:8084/BookShop/member/RandomPassword" 
                               + "?id=" + member.getId() 
                               + "&activate_code=" + member.getActivateCode()
                               + "'>ที่นี่</a></b>";

            Utility.sendMail(from, to, subject, body);
        }
            
        //  Go to View
        if (member != null) {
            RequestDispatcher rd = request.getRequestDispatcher("forgot_password_almost_complete.jsp");

            rd.forward(request, response);
        }
        else {
            request.setAttribute("usernameIncorrect", "ไม่พบชื่อผู้ใช้");

            RequestDispatcher rd = request.getRequestDispatcher("forgot_password.jsp");
            
            rd.forward(request, response);
        }
    } 

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
    * Handles the HTTP <code>GET</code> method.
    * @param request servlet request
    * @param response servlet response
    */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    } 

    /** 
    * Handles the HTTP <code>POST</code> method.
    * @param request servlet request
    * @param response servlet response
    */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
    * Returns a short description of the servlet.
    */
    public String getServletInfo() {
        return "Short description";
    }
    // </editor-fold>
}