package com.wannik.jsp.control.member;

import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;

import com.wannik.jsp.model.*;
import com.wannik.jsp.util.*;

public class Register extends HttpServlet {
    protected void processRequest(HttpServletRequest request, 
                                  HttpServletResponse response)
            throws ServletException, IOException {
        //  Prepare Input
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String confirm  = request.getParameter("confirm");
        String name     = request.getParameter("name");
        String address  = request.getParameter("address");
        String email    = request.getParameter("email");
        
        //  Validate Input
        Map<String, String> errors = new HashMap<String, String>();
        
        if (username.trim().length() == 0) {
            errors.put("username", "กรุณากรอกชื่อผู้ใช้");
        }
        
        if (password.trim().length() == 0) {
            errors.put("password", "กรุณากรอกรหัสผ่าน");
        }
        
        if (!password.equals(confirm)) {
            errors.put("confirm", "รหัสผ่านไม่ตรงกัน");
        }
        
        if (name.trim().length() == 0) {
            errors.put("name", "กรุณากรอกชื่อ");
        }
        
        if (address.trim().length() == 0) {
            errors.put("address", "กรุณากรอกที่อยู่");
        }
        
        if (!email.matches("\\S+@\\S+\\.\\S{2,3}")) {
            errors.put("email", "กรุณากรอกอีเมลให้ถูกต้อง");
        }

        if (errors.size() > 0) {
            request.setAttribute("errors", errors);

            RequestDispatcher rd = request.getRequestDispatcher("register.jsp");
            
            rd.forward(request, response);
            
            return;
        }
        
        //  Call Model
            //  Prepare Data
        boolean activated    = false;
        String  activateCode = Utility.randomText(32);
        Date    date         = new Date();
        Member  member       = new Member(username, password, name, address, 
                                          email, activated, activateCode,
                                          date);
        
            //  Add New Account & Delete Unactivated Account
        Database    db          = new Database();
        MemberTable memberTable = new MemberTable(db);

        if (memberTable.add(member)) {
            memberTable.deleteUnactivated();
        }
        else {
            errors.put("username", "ชื่อผู้ใช้ซ้ำ");
        }
        
        db.close();
        
            //  Send E-mail
        if (errors.size() == 0) {
            String from    = "no-reply@wannik.com";
            String to      = member.getEmail();
            String subject = "ยืนยันการลงเบียน";
            String body    = "คุณได้ลงทะเบียนกับเรา<br />"
                             + "โปรดยืนยันการลงทะเบียนโดยคลิก"
                             + "<b><a href='http://localhost:8084/BookShop/member/Activate" 
                               + "?id=" + member.getId() 
                               + "&activate_code=" + member.getActivateCode()
                               + "'>ที่นี่</a></b>";

            Utility.sendMail(from, to, subject, body);
        }
        
        //  Go to View
        if (errors.size() == 0) {
            RequestDispatcher rd = request.getRequestDispatcher("register_almost_complete.jsp");

            rd.forward(request, response);
        }
        else {
            request.setAttribute("errors", errors);

            RequestDispatcher rd = request.getRequestDispatcher("register.jsp");
            
            rd.forward(request, response);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
     * Returns a short description of the servlet.
     */
    public String getServletInfo() {
        return "Short description";
    }
// </editor-fold>
}