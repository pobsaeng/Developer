package com.wannik.jsp.control.member;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

import com.wannik.jsp.model.*;

public class Activate extends HttpServlet {
    protected void processRequest(HttpServletRequest request, 
                                  HttpServletResponse response)
            throws ServletException, IOException {
        //  Prepare Input
        int    id           = Integer.parseInt(request.getParameter("id"));
        String activateCode = request.getParameter("activate_code");
        
        //  Call Model
        Database    db          = new Database();
        MemberTable memberTable = new MemberTable(db);
        Member      member      = memberTable.findById(id);
        
        if (member != null 
            && member.getActivateCode().equals(activateCode)) {
            member.setActivated(true);
            
            memberTable.update(member);
        }
        
        db.close();
            
        //  Go to View
        if (member != null
            && member.getActivateCode().equals(activateCode)) {
            response.sendRedirect("register_completed.jsp");
        }
        else {
            response.sendRedirect("register_failed.jsp");
        }
    } 

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
    * Handles the HTTP <code>GET</code> method.
    * @param request servlet request
    * @param response servlet response
    */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    } 

    /** 
    * Handles the HTTP <code>POST</code> method.
    * @param request servlet request
    * @param response servlet response
    */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
    * Returns a short description of the servlet.
    */
    public String getServletInfo() {
        return "Short description";
    }
    // </editor-fold>
}