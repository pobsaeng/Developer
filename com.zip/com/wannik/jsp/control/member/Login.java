package com.wannik.jsp.control.member;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

import com.wannik.jsp.model.*;

public class Login extends HttpServlet {
    protected void processRequest(HttpServletRequest request, 
                                  HttpServletResponse response)
            throws ServletException, IOException {
        //  Prepare Input
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        
        //  Call Model
        HttpSession session     = request.getSession();
        Database    db          = new Database();
        MemberTable memberTable = new MemberTable(db);
        Member      member      = memberTable.findByUP(username, password);
        
        db.close();
        
        //  Go to View
        if (member != null && member.isActivated()) {
            ShoppingCart cart = (ShoppingCart) session.getAttribute("cart");
            
            session.setAttribute("member", member);
            
            if (cart != null && cart.getItems().size() > 0) {
                response.sendRedirect("../shop/shipping.jsp");
            } 
            else {
                response.sendRedirect("../shop/index.jsp");
            }
        }
        else {
            if (member == null) {
                request.setAttribute("loginIncorrect", "ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง");
            }
            else {
                request.setAttribute("loginIncorrect", "บัญชียังไม่ผ่านการยืนยัน");
            }
            
            RequestDispatcher rd = request.getRequestDispatcher("login.jsp");
            
            rd.forward(request, response);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
     * Returns a short description of the servlet.
     */
    public String getServletInfo() {
        return "Short description";
    }
    // </editor-fold>
}